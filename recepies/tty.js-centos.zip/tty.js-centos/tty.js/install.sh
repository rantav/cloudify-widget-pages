#!/bin/bash
set -x -e
sudo npm install -g tty.js