#!/bin/bash
set -x -e

tty.js --port 8080 --deamonize


