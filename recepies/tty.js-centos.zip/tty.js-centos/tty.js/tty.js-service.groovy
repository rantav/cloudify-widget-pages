service {
    extend "../generic"
    name "tty.js"
}
