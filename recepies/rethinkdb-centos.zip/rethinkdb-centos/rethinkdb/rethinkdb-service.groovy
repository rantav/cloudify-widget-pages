service {
    extend "../generic"
    name "rethinkdb"
}