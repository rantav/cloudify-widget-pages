#!/bin/bash

sudo yum install -y rethinkdb