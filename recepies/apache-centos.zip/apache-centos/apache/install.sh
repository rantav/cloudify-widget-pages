#!/bin/bash
sudo yum -y install httpd
