service { 
    extend "../generic"
    name "apache"
}