#!/bin/bash

sudo service httpd restart