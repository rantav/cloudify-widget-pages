#!/bin/bash

echo init