#!/bin/bash
set -x -e

nohup /usr/lib/jvm/jre-1.7.0/bin/java -jar gitbucket.war &


