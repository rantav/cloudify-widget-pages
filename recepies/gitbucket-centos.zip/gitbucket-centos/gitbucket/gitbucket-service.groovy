service {
    extend "../generic"
    name "gitbucket"
}
