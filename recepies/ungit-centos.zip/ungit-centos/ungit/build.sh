#!/bin/bash
set -x -e
sudo yum install -y make gcc gcc-c++
