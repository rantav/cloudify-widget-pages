#!/bin/bash
set -x
sudo yum install -y make gcc gcc-c++
