#!/bin/bash
set -x
yum install -y make gcc gcc-c++
