#!/bin/bash

nohup rethinkdb --bind all &