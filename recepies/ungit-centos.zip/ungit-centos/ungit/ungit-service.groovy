service {
    extend "../generic"
    name "ungit"
}
