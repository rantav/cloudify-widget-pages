#!/bin/bash
set -x -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source $DIR/build.sh
source $DIR/git.sh
source $DIR/npm.sh

sudo npm install -g tty.js