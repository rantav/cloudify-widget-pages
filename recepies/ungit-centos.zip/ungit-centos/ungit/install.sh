#!/bin/bash
set -x -e
sudo npm install -g ungit
