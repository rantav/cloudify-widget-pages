#!/bin/bash
set -x
sudo npm install -g ungit
