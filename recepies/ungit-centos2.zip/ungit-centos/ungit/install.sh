#!/bin/bash

sudo npm install -g ungit
